// Wait for DOM
document.addEventListener('DOMContentLoaded', function() {

  // EMAIL
  var el = document.getElementById('email-link');
  if (el) el.href = 'mailto:adideepakk19@gmail.com';

  // TYPEWRITER
  var phrases = ['Data Analyst', 'ML Engineer', 'BI Developer', 'Analytics Strategist'];
  var pi = 0, ci = 0, deleting = false;
  var tw = document.getElementById('tw-text');
  function typeLoop() {
    if (!tw) return;
    var word = phrases[pi];
    tw.textContent = deleting ? word.slice(0, ci--) : word.slice(0, ci++);
    if (!deleting && ci > word.length) { deleting = true; setTimeout(typeLoop, 1200); return; }
    if (deleting && ci < 0) { deleting = false; pi = (pi + 1) % phrases.length; ci = 0; setTimeout(typeLoop, 350); return; }
    setTimeout(typeLoop, deleting ? 50 : 90);
  }
  typeLoop();

  // PARALLAX ORBS
  var orb1 = document.getElementById('orb1');
  var orb2 = document.getElementById('orb2');
  var orb3 = document.getElementById('orb3');
  window.addEventListener('scroll', function() {
    var sy = window.scrollY;
    if (orb1) orb1.style.transform = 'translate(' + (sy*0.04) + 'px,' + (sy*0.07) + 'px)';
    if (orb2) orb2.style.transform = 'translate(' + (-sy*0.05) + 'px,' + (-sy*0.04) + 'px)';
    if (orb3) orb3.style.transform = 'translate(' + (sy*0.02) + 'px,' + (-sy*0.06) + 'px)';
  }, { passive: true });

  // CURSOR TRAIL
  var TRAIL = 16;
  var colors = ['rgba(200,169,110,', 'rgba(124,159,255,', 'rgba(167,139,250,'];
  var dots = [];
  for (var i = 0; i < TRAIL; i++) {
    var d = document.createElement('div');
    d.style.cssText = 'position:fixed;border-radius:50%;pointer-events:none;z-index:9999;transform:translate(-50%,-50%);opacity:0;transition:opacity 0.1s;';
    var size = Math.max(3, 8 - i * 0.3);
    d.style.width = size + 'px';
    d.style.height = size + 'px';
    d.style.background = colors[i % 3] + (1 - i / TRAIL) * 0.85 + ')';
    document.body.appendChild(d);
    dots.push({ el: d, x: -100, y: -100 });
  }
  var mx = -100, my = -100, trailStarted = false;
  document.addEventListener('mousemove', function(e) {
    mx = e.clientX; my = e.clientY; trailStarted = true;
  });
  function animTrail() {
    var px = mx, py = my;
    for (var j = 0; j < dots.length; j++) {
      var spd = 0.35 - j * 0.015;
      dots[j].x += (px - dots[j].x) * spd;
      dots[j].y += (py - dots[j].y) * spd;
      dots[j].el.style.left = dots[j].x + 'px';
      dots[j].el.style.top = dots[j].y + 'px';
      dots[j].el.style.opacity = trailStarted ? (1 - j / dots.length) * 0.85 : 0;
      px = dots[j].x; py = dots[j].y;
    }
    requestAnimationFrame(animTrail);
  }
  animTrail();

  // MOBILE NAV
  window.toggleNav = function() { document.getElementById('nav-links').classList.toggle('open'); };
  window.closeNav  = function() { document.getElementById('nav-links').classList.remove('open'); };

  // NAV ACTIVE HIGHLIGHT
  window.addEventListener('scroll', function() {
    var sections = document.querySelectorAll('section[id]');
    var links    = document.querySelectorAll('.nav-links a');
    var current  = '';
    sections.forEach(function(s) { if (window.scrollY >= s.offsetTop - 130) current = s.id; });
    links.forEach(function(a) {
      a.style.color = a.getAttribute('href') === '#' + current ? 'var(--accent)' : '';
    });
  });

});
